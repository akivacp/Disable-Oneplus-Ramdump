#!/system/bin/sh
# post-fs-data.sh
# Runs early in boot (post-fs-data stage).
# Copies the disable-ramdump script into Magisk's service.d so it
# persists across module updates and runs at every boot.

mkdir -p /data/adb/service.d
cp -f /system/bin/disable-ramdump.sh /data/adb/service.d/disable-ramdump.sh
chmod 755 /data/adb/service.d/disable-ramdump.sh
