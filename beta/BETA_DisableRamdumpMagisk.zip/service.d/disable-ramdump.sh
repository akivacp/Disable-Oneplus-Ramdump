#!/system/bin/sh
# disable-ramdump.sh
# Placed in /system/bin/ by Magisk and copied to /data/adb/service.d/
# by post-fs-data.sh so it runs on every boot.
#
# CHANGELOG
# v1.2 (versionCode 3) - 2026-05-08
#   FIXED: Removed *.bin from auto-delete patterns — too generic, could
#         match non-dump vendor files on some OxygenOS builds.
#   FIXED: Replaced catch-all find+rm (deleted ALL unknown files) with a
#         log-only pass — unknown files are now listed in the log but NOT
#         deleted automatically. This prevents accidental removal of files
#         we don't recognise on the user's specific firmware.
#   UNCHANGED: *.elf, *.dump, *.gz, *.lzo, DDRCS*, load.cmm, rpmh_data*
#         auto-delete retained — these are unambiguous Qualcomm SSR artifacts.
# v1.1 (versionCode 2) - 2026-05-08
#   ADDED: Safe cleanup of existing ramdump files before locking directory.
#   ADDED: Logging to /data/adb/disable-ramdump.log.
#   UNCHANGED: setprop, chmod 000, chattr +i logic from v1.0.
# v1.0 (versionCode 1) - original
#   Disables ramdump property, locks directory permissions, makes immutable.
#
# SAFETY NOTES:
#   - Only files INSIDE /data/vendor/ramdump are removed, never the dir itself.
#   - chattr -i is called before any writes, then re-applied after.
#   - No system partitions are touched.

LOG=/data/adb/disable-ramdump.log
RAMDUMP_DIR=/data/vendor/ramdump

# ── log() ──────────────────────────────────────────────────────────────────
# Appends a timestamped message to the log file.
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

log "=== disable-ramdump started ==="

# ── Step 1: Disable the ramdump system property ────────────────────────────
# Tells Qualcomm's diagnostic service not to trigger ramdumps on crash.
setprop persist.vendor.ramdump.enable 0
log "setprop persist.vendor.ramdump.enable 0"

# ── Step 2: Clean existing dump files ─────────────────────────────────────
# Only runs if the directory exists and is not already immutable.
# Removes known ramdump file patterns without touching the directory itself.
if [ -d "$RAMDUMP_DIR" ]; then
    # Temporarily lift immutable flag in case a previous run already set it.
    # chattr -i fails silently if the flag was never set — that is fine.
    chattr -i "$RAMDUMP_DIR" 2>/dev/null

    CLEANED=0

    # Remove unambiguous Qualcomm SSR ramdump artifacts only.
    # *.bin intentionally excluded — too generic for some OxygenOS builds.
    for pattern in "*.elf" "*.dump" "*.gz" "*.lzo" "DDRCS*" "load.cmm" "rpmh_data*"; do
        for f in "$RAMDUMP_DIR"/$pattern; do
            [ -f "$f" ] || continue          # skip if glob matched nothing
            rm -f "$f" && CLEANED=$((CLEANED + 1)) && log "  removed: $f"
        done
    done

    # Log any remaining unknown files but do NOT delete them automatically.
    # Check the log after first boot and decide if they are safe to remove.
    find "$RAMDUMP_DIR" -maxdepth 1 -type f | while read -r f; do
        log "  UNKNOWN (not auto-removed, review manually): $f"
    done

    log "Cleanup done. Auto-removed: $CLEANED file(s). See UNKNOWN lines above for anything unrecognised."
else
    log "RAMDUMP_DIR not found — nothing to clean."
fi

# ── Step 3: Lock down the directory ───────────────────────────────────────
# chmod 000  — no process (even root) can list or enter without sudo
# chattr +i  — immutable flag prevents any writes at the kernel level
chmod 000 "$RAMDUMP_DIR"
chattr +i "$RAMDUMP_DIR"
log "chmod 000 + chattr +i applied to $RAMDUMP_DIR"

log "=== disable-ramdump done ==="
